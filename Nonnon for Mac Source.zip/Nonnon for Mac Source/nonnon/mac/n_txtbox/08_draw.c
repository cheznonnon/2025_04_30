// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




void
n_mac_image_alpha_grow( n_bmp *bmp, u32 color_replace, n_type_real d )
{

	if ( n_bmp_error( bmp ) ) { return; }


	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{//break;

		u32 color; n_bmp_ptr_get_fast( bmp, x, y, &color );

		int a = n_posix_min( 255, trunc( (n_type_real) n_bmp_a( color ) * d ) );
		int r = n_bmp_r( color_replace );
		int g = n_bmp_g( color_replace );
		int b = n_bmp_b( color_replace );

		color = n_bmp_argb( a,r,g,b );

		n_bmp_ptr_set_fast( bmp, x, y, color );

		x++;
		if ( x >= N_BMP_SX( bmp ) )
		{
			x = 0;
			y++;
			if ( y >= N_BMP_SY( bmp ) ) { break; }
		}
	}


	return;
}




NSColor*
n_txtbox_thin_highlight( n_txt *txt, n_txt *txt_deco, n_type_int i, NSColor *f, NSColor *t )
{

	NSColor *ret = f;

	if ( ( txt_deco != NULL )&&( txt->sy == txt_deco->sy ) )
	{
		n_posix_char *deco = n_txt_get( txt_deco, i );
		if ( ( 2 <= n_posix_strlen( deco ) )&&( deco[ 1 ] == '!' ) )
		{
			ret = n_mac_nscolor_blend( f, t, 0.2 );
		}
	}


	return ret;
}




@implementation NonnonTxtbox (NonnonTxtboxDraw)


- (BOOL) isFlipped
{
	return YES;
}




- (void) NonnonTxtboxDrawScrollClamp
{

	// [!] : this code is same as drawRect

	n_type_gfx scroll_csy = (n_type_gfx) self.frame.size.height - ( offset * 2 );

	const n_type_gfx scroll_pixel_sx = 12;

	if ( n_corner_size == -1 ) { n_corner_size = scroll_pixel_sx; }
//NSLog( @"%f", n_corner_size );

	CGFloat shaft_sy         = scroll_csy - n_corner_size;
	CGFloat items_per_canvas = shaft_sy / font_size.height;
	//CGFloat max_count        = (CGFloat) n_txt_data->sy;
	CGFloat rest             = font_size.height - fmod( shaft_sy, font_size.height );


	CGFloat txt_sy = n_txt_data->sy;

	if ( txt_sy <= 1 )
	{
		scroll = 0;
	} else
	if ( items_per_canvas < txt_sy )
	{
		if ( rest ) { items_per_canvas -= 1.0; }

		CGFloat max_sy = txt_sy - items_per_canvas;

		if ( scroll <       0 ) { scroll =      0; } else
		if ( scroll >= max_sy ) { scroll = max_sy; }
	} else {
		scroll = 0;
	}

//NSLog( @"%lld : %lld %lld", n_focus, caret_fr.cch.y, caret_to.cch.y );

}




- (void) NonnonTxtboxDrawCaretCalculate
{

	// [!] : caret on the current screen

	n_caret pt = caret_fr;

	if ( caret_fr.cch.y == caret_to.cch.y )
	{
		if ( caret_fr.cch.y == n_focus )
		{
			if ( caret_fr.pxl.x == caret_to.pxl.x )
			{
//NSLog( @"==" );
				//
			} else
			if ( caret_fr.pxl.x < caret_to.pxl.x )
			{
//NSLog( @"< : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = caret_to;
			} else {
//NSLog( @"> : %0.2f %0.2f", caret_fr.pxl.x, caret_to.x );
				pt = caret_to;
			}
		}
	} else
	if ( caret_fr.cch.y < caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { pt = caret_to; }
	} else
	if ( caret_fr.cch.y > caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { pt = caret_to; }
	}

	caret_pt.x = padding + pt.pxl.x - 1;
	caret_pt.y = offset + ( ( pt.cch.y - trunc( scroll ) ) * font_size.height );


#ifdef N_TXTBOX_IME_ENABLE

	// [!] : Sonoma : popup indicator is implemented : this is used in the first time

	ime_caret_fr = caret_fr;
	ime_caret_to = caret_to;

#endif


	return;
}

- (BOOL) NonnonTxtboxDrawCaretIsOnScreen
{
#ifdef N_TXTBOX_IME_ENABLE

	if ( ime_onoff )
	{
		return FALSE;
	}

#endif


	[self NonnonTxtboxDrawCaretCalculate];


	BOOL ret = FALSE;

	if ( caret_fr.cch.y == caret_to.cch.y )
	{
		if ( caret_fr.cch.y == n_focus ) { ret = TRUE; }
	} else
	if ( caret_fr.cch.y < caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { ret = TRUE; }
	} else
	if ( caret_fr.cch.y > caret_to.cch.y )
	{
		if ( caret_to.cch.y == n_focus ) { ret = TRUE; }
	}


	return ret;
}

- (void) NonnonTxtboxDrawCaretDraw:(void*)zero rect:(NSRect)rect color_bg:(u32)color_bg color_stripe:(u32)color_stripe focus:(n_type_int)focus
{
//return;

	double d;

	if ( [self window].keyWindow == FALSE )
	{
		d = 0.1;
	} else
	if ( n_txtbox_first_responder != self )
	{
		d = 0.1;
	} else
	if ( caret_blink_force_onoff )
	{
		d = 1.0;
	} else {
		if ( caret_blink_onoff )
		{
//NSLog( @"On %d", caret_blink_fade.percent );
			d = caret_blink_fade.percent * 0.01;
		} else {
//NSLog( @"Off %d", caret_blink_fade.percent );
			d = caret_blink_fade.percent * 0.01;
			d = 1.0 - d;
		}
	}

//NSLog( @"Percent %f", d );


	u32 color       = 0;
	u32 color_caret = 0;

	if ( focus & 1 )
	{
		color = color_stripe;
	} else {
		color = color_bg;
	}

	if ( is_darkmode )
	{
		color_caret = n_bmp_white;
	} else {
		color_caret = n_bmp_black + 1;
	}

	color = n_bmp_blend_pixel( color, color_caret, (double) d );

	NSColor *clr = n_mac_argb2nscolor( color );
	n_mac_draw_box_invert( clr, rect );

}

- (void) NonnonTxtboxDrawCaret_drawRect:(void*)n_nil
	             max_sx:(CGFloat)max_sx
	delete_circle_onoff:(BOOL)   delete_circle_onoff
	           color_bg:(u32)    color_bg
	       color_stripe:(u32)    color_stripe
{

	if ( ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )&&( self.n_listbox_edit_onoff == FALSE ) )
	{
		//
	} else
	if ( delete_circle_fade_pressed_phase )
	{
		//
	} else
	if ( [self NonnonTxtboxDrawCaretIsOnScreen] )
	{
		if ( ( delete_circle_onoff )&&( caret_pt.x > max_sx ) )
		{
			//
		} else {
			NSRect rect = NSMakeRect( caret_pt.x, caret_pt.y - caret_centered_offset, 1, font_size.height );
			[self NonnonTxtboxDrawCaretDraw:nil rect:rect color_bg:color_bg color_stripe:color_stripe focus:n_focus];
		}
	}

}

- (void) NonnonTxtboxDrawFindIconMake:(void*)zero color:(u32)color_replace offset:(n_type_gfx)o
{
//return;

	n_bmp bmp; n_bmp_carboncopy( self.n_findbox_bmp_icon, &bmp );


	int replace_r = n_bmp_r( color_replace );
	int replace_g = n_bmp_g( color_replace );
	int replace_b = n_bmp_b( color_replace );

	n_type_gfx x = 0;
	n_type_gfx y = 0;
	n_posix_loop
	{//break;
		u32 c; n_bmp_ptr_get_fast( &bmp, x,y, &c );

		int a = n_bmp_a( c );
		if ( a != 0 )
		{
			int r = replace_r;
			int g = replace_g;
			int b = replace_b;

			c = n_bmp_argb( a,r,g,b );

			n_bmp_ptr_set_fast( &bmp, x,y, c );
		}

		x++;
		if ( x >= N_BMP_SX( &bmp ) )
		{
			x = 0;
			y++;
			if ( y >= N_BMP_SY( &bmp ) ) { break; }
		}
	}


	CGFloat sz = self.frame.size.height - 6;
/*
	int i = 0;
	n_posix_loop
	{
		n_bmp_flush_antialias( &bmp, 1.0 );

		i++;
		if ( sz > ( N_BMP_SY( &bmp ) / i ) ) { break; }
	}

	n_mac_image_alpha_grow( &bmp, color_replace, 3 );
*/

	CGFloat c = ( self.frame.size.height - sz ) / 2;
	CGFloat p = 0;

	if ( find_icon_is_pressed )
	{
		p = 1;
	}

	find_icon_rect = NSMakeRect( o+p,c+p, sz,sz );


//n_bmp_save( &bmp, "/Users/nonnon/Desktop/ret.bmp" );
	find_icon_cache_nsimage = n_mac_image_nbmp2nsimage( &bmp );


	// [!] : find_icon_cache_nsimage seems to use this pointer
	//n_bmp_free_fast( &bmp );


	return;
}

- (NSRect) NonnonTxtboxDrawTextAdjust:(NSString*) text rect:(NSRect) rect
{

	CGSize size = n_mac_image_text_pixelsize( text, font );

	CGFloat cx = ( rect.size.width  - size.width  ) / 2;
	CGFloat cy = ( rect.size.height - size.height ) / 2;

	NSRect ret = NSMakeRect(
		rect.origin.x    + cx,
		rect.origin.y    + cy,
		rect.size.width  - cx,
		rect.size.height - cy
	);

	return ret;
}

- (void)drawRect:(NSRect)rect
{
//NSLog( @"drawRect" );

//u32 tick = n_posix_tickcount();

//NSLog( @"%lld", n_test_txt.sy );


	// [x] : Sonoma Xcode 15 : rect has window size at the first run

	{
		NSRect r = [super bounds];
		if (
			( r.size.width  < rect.size.width  )
			||
			( r.size.height < rect.size.height )
		)
		{
			rect = r;
		}
	}


	// [!] : redraw

	BOOL is_whole_redraw;

	if (
		( self.frame.size.width  == rect.size.width  )
		&&
		( self.frame.size.height == rect.size.height )
	)
	{
		is_whole_redraw = TRUE;
	} else {
		is_whole_redraw = FALSE;
	}

	// [x] : partially redraw : too much hard to implement
	//
	//	drawRect will be called with as gray-filled image
/*
	BOOL debug = FALSE;
	if ( redraw_fy == 0 )
	{
		debug = TRUE;
	}
*/

	// [Patch] : not supported yet

	if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
	{
		is_whole_redraw = TRUE;
	}

	if ( is_whole_redraw )
	{
		redraw_fy = 0;
		redraw_ty = n_txt_data->sy;
	}

	//redraw_fy = 1;
	//redraw_ty = 2;


	BOOL delete_circle_onoff = FALSE;
	if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		if ( 0 != n_posix_strlen( n_txt_get( n_txt_data, 0 ) ) )
		{
			delete_circle_onoff = TRUE;
		}
	}


	// [!] : Metrics

	is_darkmode = n_mac_is_darkmode();

	[self NonnonTxtboxDrawScrollClamp];

	n_type_gfx csx = (n_type_gfx) self.frame.size.width;
	n_type_gfx csy = (n_type_gfx) self.frame.size.height;

	CGFloat o = offset;
//NSLog( @"%f", offset );

	caret_centered_offset = 0;

	if (
		( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
		||
		( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )

	)
	{
		caret_centered_offset = ( ( font_size.height + ( o * 2 ) ) - csy ) / 2;
	} else {
		CGFloat minim = font_size.height + ( o * 2 );
		if ( ( csx < minim )||( csy < minim ) ) { return; }
	}

	if ( caret_fr.cch.y >= n_txt_data->sy ) { caret_fr.cch.y = n_txt_data->sy - 1; }


	// [!] : Metrics 2 : Colors

	NSColor *nscolor_text;
	if ( is_darkmode )
	{
		nscolor_text = n_mac_nscolor_argb( 255,222,222,222 );
	} else {
		nscolor_text = [NSColor textColor];
	}

	NSColor *nscolor_back  = [NSColor textBackgroundColor];
	if ( is_grayed )
	{
		nscolor_text = n_mac_nscolor_blend( nscolor_back, nscolor_text, 0.55 );
		nscolor_back = n_mac_nscolor_blend( nscolor_back, nscolor_text, 0.05 );
	}

	u32        color_bg    = n_mac_nscolor2argb( nscolor_back );
	u32        color_fg    = n_mac_nscolor2argb( nscolor_text );
	u32        color_frame = n_bmp_blend_pixel( color_bg, color_fg, 0.25 );
	NSColor *nscolor_frame = n_mac_argb2nscolor( color_frame );
	NSColor *nscolor_text_normal = nscolor_text;

	NSColor *nscolor_text_highlight;
	if ( is_darkmode )
	{
		nscolor_text_highlight = nscolor_text;
	} else {
		nscolor_text_highlight = nscolor_back;
	}

	u32        color_stripe;
	NSColor *nscolor_stripe;

	if ( is_darkmode )
	{
		  color_stripe = n_bmp_blend_pixel( color_bg, color_fg, 0.10 );
		nscolor_stripe = n_mac_argb2nscolor( color_stripe );
	} else {
		  color_stripe = n_bmp_blend_pixel( color_bg, color_fg, 0.05 );
		nscolor_stripe = n_mac_argb2nscolor( color_stripe );
	}
	
	u32        color_crlf = n_bmp_blend_pixel( color_bg, color_fg, 0.25 );
	NSColor *nscolor_crlf = n_mac_argb2nscolor( color_crlf );

	NSColor *nscolor_accent = [NSColor controlAccentColor];

	NSColor *nscolor_nofocus;
	if ( is_darkmode )
	{
		nscolor_nofocus = n_mac_nscolor_argb( 255,100,100,100 );
	} else {
		nscolor_nofocus = n_mac_nscolor_argb( 255,200,200,200 );
	}

#ifdef N_TXTBOX_IME_ENABLE
	//NSColor *nscolor_ime = [nscolor_accent blendedColorWithFraction:0.33 ofColor:nscolor_stripe];
	NSColor *nscolor_ime = nscolor_accent;
#endif


	// [!] : Fake Caret : Fast Mode

	if ( is_whole_redraw )
	{
		//
	} else
	if ( ime_onoff )
	{
		//
	} else
	if ( redraw_caret_only )
	{

		[self NonnonTxtboxDrawCaret_drawRect:nil
				     max_sx:( csx - csy + o )
			delete_circle_onoff:delete_circle_onoff
				   color_bg:color_bg
			       color_stripe:color_stripe
		];

		redraw_caret_only = FALSE;

		return;
	}


	// [!] : Contents

	if ( is_whole_redraw )
	{
		if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			//
		} else {
			n_mac_draw_box( nscolor_back, self.frame );
		}
	}
//n_mac_draw_box( n_mac_nscolor_argb( 255,0,200,255 ), self.frame );


	// [!] : Find Icon

	if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		if ( self.n_findbox_bmp_icon != NULL )
		{
			// [!] : for reducing CPU usage

			BOOL focus_cur = ( n_txtbox_first_responder == self );
//NSLog( @"Prev %d : Cur %d", find_icon_focus_prev, focus_cur );


			BOOL fade_init = FALSE;

			static int fade_type = 0;

			if ( ( focus_cur )&&( find_icon_focus_prev == FALSE ) ) 
			{
//NSLog( @"Up" );
				fade_init = TRUE;
				fade_type = 1;
			} else
			if ( ( focus_cur == FALSE )&&( find_icon_focus_prev ) ) 
			{
//NSLog( @"Down" );
				fade_init = TRUE;
				fade_type = 2;
			}

			find_icon_focus_prev = focus_cur;

			if ( fade_init )
			{
//NSLog( @"Init" );
				fade_init = FALSE;

				n_bmp_fade_init( &find_icon_fade, n_bmp_black );
				n_bmp_fade_go  ( &find_icon_fade, n_bmp_white );
			}


			BOOL blend_onoff = FALSE;

			n_type_real d = 1.0;
			if ( find_icon_fade.stop == n_posix_false )
			{
				blend_onoff = TRUE;

				d = find_icon_fade.percent * 0.01;
				if ( fade_type == 2 ) { d = 1.0 - d; }
			}


			u32 color_nrml = n_bmp_blend_pixel( color_fg, color_bg, 0.25 );
			u32 color_main;

			if ( blend_onoff )
			{
				color_main = n_bmp_blend_pixel( color_nrml, n_bmp_white, d );
			} else
			if ( focus_cur )
			{
				color_main = n_bmp_white;
			} else {
				color_main = color_nrml;
			}


			// [!] : for reducing CPU usage

			static u32  prv_color = 0;
			static BOOL prv_press = FALSE;

			if ( ( prv_color == 0 )||( prv_color != color_main ) )
			{
				[self NonnonTxtboxDrawFindIconMake:NULL color:color_main offset:o];
			} else
			if ( prv_press != find_icon_is_pressed )
			{
				[self NonnonTxtboxDrawFindIconMake:NULL color:color_main offset:o];
			}
//NSLog( @"%x %x", prv_color, color_main );
//NSLog( @"%d %d", prv_press, find_icon_is_pressed );
//NSLog( @"%d", find_icon_fade.percent );

			prv_color = color_main;
			prv_press = find_icon_is_pressed;


			NSColor *nscolor_bg = nscolor_back;
			NSColor *nscolor_fg = [NSColor controlAccentColor];

			if ( blend_onoff )
			{
				NSColor *nscolor = n_mac_nscolor_blend( nscolor_bg, nscolor_fg, d );
				n_mac_draw_circle( nscolor, find_icon_rect );
			} else
			if ( focus_cur )
			{
				n_mac_draw_circle( nscolor_fg, find_icon_rect );
			} else {
				//n_mac_draw_circle( nscolor_bg, find_icon_rect );
			}

			NSRect rect = n_mac_rect_resize( find_icon_rect, -2 );
			[find_icon_cache_nsimage drawInRect:rect];
		}
	}


	// [!] : n_txt rendering engine

//NSLog( @"%f %f", caret_fr.pxl.x, caret_to.pxl.x );

	NSMutableDictionary *attr = [NSMutableDictionary dictionary];
	[attr setObject:font forKey:NSFontAttributeName];

	NSMutableDictionary *attr_crlf = [NSMutableDictionary dictionary];
	[attr_crlf setObject:linenumber_font forKey:NSFontAttributeName];
	[attr_crlf setObject:nscolor_crlf    forKey:NSForegroundColorAttributeName];

#ifdef N_TXTBOX_IME_ENABLE

	NSMutableDictionary *attr_ime = [NSMutableDictionary dictionary];
	[attr_ime setObject:font forKey:NSFontAttributeName];
	//[attr_ime setObject:[NSNumber numberWithInt:NSUnderlineStyleDouble] forKey:NSUnderlineStyleAttributeName ];

#endif

	NSRect r = NSMakeRect( padding, o - caret_centered_offset, self.frame.size.width - ( o * 2 ), font_size.height );

	CGFloat max_sy = self.frame.size.height - ( o * 2 );

	NSRect listbox_rect = NSMakeRect( 0,0,0,0 );

#ifdef N_TXTBOX_IME_ENABLE

	NSRect  underline_rect = NSMakeRect( -1,-1,-1,-1 );
	CGFloat underline_fx   = -1;
	CGFloat underline_tx   = -1;

#endif


	// [!] : before text rendering : for some fonts like "g"

	{

		NSRect rect = r;

		n_type_int i = scroll;
		n_posix_loop
		{//break;

			if (
				( is_whole_redraw )
				||
				( ( redraw_fy <= i )&&( i < redraw_ty ) )
			)
			{
				NSColor *nscolor;
				if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
				{
					nscolor = nscolor_back;
				} else
				if ( i & 1 )
				{
					nscolor = nscolor_stripe;
				} else {
					nscolor = nscolor_back;
				}

				nscolor = n_txtbox_thin_highlight( n_txt_data, n_txt_deco, i, nscolor, nscolor_accent );

				if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
				{
					n_mac_draw_box( nscolor, self.frame );
				} else {
					n_mac_draw_box( nscolor, rect );
				}
			}

			rect.origin.y += font_size.height;
			if ( rect.origin.y > max_sy ) { break; }

			i++;
		}
	}


	n_type_int i = scroll;
//NSLog( @"%f %lld", scroll, n_mac_listbox_txt.sy );
	n_posix_loop
	{//break;

		n_posix_char *line = n_txt_get( n_txt_data, i );

		if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			if ( i == self.n_focus )
			{
				if ( self.n_listbox_edit_onoff )
				{
//NSLog( @"%f", o );
					listbox_rect = r;
					listbox_rect.size.width = csx - padding - o;
				} else {
					if ( n_txt_data->readonly )
					{
						n_mac_draw_box( nscolor_nofocus, r );
					} else {
						n_mac_draw_box( nscolor_accent , r );
					}
				}
			}
		}

		if ( ( redraw_fy <= i )&&( i < redraw_ty )&&( i < n_txt_data->sy ) )
		{
//[text drawInRect:r withAttributes:attr];

			if ( ( n_txt_deco != NULL )&&( n_txt_data->sy == n_txt_deco->sy ) )
			{
				n_posix_char *deco = n_txt_get( n_txt_deco, i );

				// [x] : italic : no better way

				if ( ( self.n_listbox_edit_onoff )&&( i == n_focus ) )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.0];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == ' ' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.2];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == 'B' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.0];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleNone];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == 'u' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.2];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleSingle];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				} else
				if ( deco[ 0 ] == 'U' )
				{
					NSNumber *n = [NSNumber numberWithDouble:0.0];
					[attr setObject:n forKey:NSObliquenessAttributeName ];

					NSNumber *u = [NSNumber numberWithInt:NSUnderlineStyleSingle];
					[attr setObject:u forKey:NSUnderlineStyleAttributeName ];
				}
			}


			BOOL    gradient_onoff  = FALSE;
			NSRect  gradient_rect   = NSMakeRect( 0,0,0,0 );
			CGFloat gradient_cut    = (CGFloat) csx - csy - csy;
			BOOL    roundrect_onoff = FALSE;

			if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				roundrect_onoff = TRUE;

				n_type_int index = 0;
				CGFloat    sx    = 0;
				n_type_int tab   = 0;
				n_posix_loop
				{//break;
					if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

					CGSize     char_size;
					n_type_int char_index;
					NSRect     char_rect = r;

					n_posix_char *character;
					character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );

					char_rect.origin.x   += sx;
					char_rect.origin.x   -= 1;
					char_rect.size.width  = char_size.width + 1;


					index += char_index;
					sx    += char_size.width;

//NSLog( @"%f %f", ceil( sx ), (CGFloat) csx - csy - csy );
					if ( ceil( sx ) > gradient_cut )
					{
						gradient_onoff = TRUE;

						gradient_rect = char_rect;
						gradient_rect.origin.x   = gradient_cut - csy;
						gradient_rect.size.width = csx - gradient_rect.origin.x;

						roundrect_onoff = FALSE;

						break;
					}
				}
			}


			int round_mode = N_MAC_DRAW_ROUNDRECT_LEFT;

			{
				n_type_int index = 0;
				CGFloat    sx    = 0;
				n_type_int tab   = 0;
				n_posix_loop
				{//break;
					if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

					CGSize     char_size;
					n_type_int char_index;
					NSRect     char_rect = r;

					n_posix_char *character;
					character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );

					char_rect.origin.x   += sx;
					char_rect.origin.x   -= 1;
					char_rect.size.width  = char_size.width + 1;

					NSPoint pt = NSMakePoint( sx, i );

					sx += char_size.width;

					BOOL selected = n_mac_txtbox_is_selected( pt, caret_fr.pxl.x, caret_fr.cch.y, caret_to.pxl.x, caret_to.cch.y );
					if ( selected )
					{
						BOOL focus = ( n_txtbox_first_responder == self );

						NSColor *nscolor;
						if ( focus )
						{
							nscolor = nscolor_accent;
						} else {
							nscolor = nscolor_nofocus;
						}

						if ( delete_circle_fade_pressed.stop == FALSE )
						{
							NSColor *f = nscolor;
							NSColor *t = [NSColor whiteColor];

							nscolor = n_mac_nscolor_blend( f, t, delete_circle_fade_pressed.percent * 0.01 );
						}

						if ( ( ( gradient_onoff ) )&&( ceil( sx ) > gradient_rect.origin.x ) )
						{
							n_mac_draw_gradient( nscolor, nscolor_back, gradient_rect );

							break;
						} else
						if ( roundrect_onoff )
						{
							const n_type_gfx round_param = 3;
							n_mac_draw_roundrect_partial( nscolor, char_rect, round_param, round_mode );

							if (
								( line[ index + 1 ] != N_STRING_CHAR_NUL )
								&&
								( line[ index + 2 ] == N_STRING_CHAR_NUL )
							)
							{
								round_mode = N_MAC_DRAW_ROUNDRECT_RIGHT;
							} else {
								round_mode = N_MAC_DRAW_ROUNDRECT_NONE;
							}
						} else {
							n_mac_draw_box( nscolor, char_rect );
						}
					}

					index += char_index;

				}
			}


			n_type_int index = 0;
			CGFloat    sx    = 0;
			n_type_int tab   = 0;
			n_posix_loop
			{//break;
				if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

				CGSize     char_size;
				n_type_int char_index;
				NSRect     char_rect = r;

				n_posix_char *character;
				character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );
//NSLog( @"#%lld : %ld", i, strlen( character ) );

				char_rect.origin.x   += sx;
				char_rect.origin.x   -= 1;
				char_rect.size.width  = char_size.width + 1;


				NSPoint pt = NSMakePoint( sx, i );

				BOOL selected = n_mac_txtbox_is_selected( pt, caret_fr.pxl.x, caret_fr.cch.y, caret_to.pxl.x, caret_to.cch.y );
				if ( ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )&&( self.n_listbox_edit_onoff == FALSE ) )
				{
					if ( i == self.n_focus )
					{
						selected = TRUE;
					}
				}


				if ( line[ index ] == N_STRING_CHAR_TAB )
				{

					NSRect r = char_rect; r.size.width = 0.5;

					n_mac_draw_box( nscolor_crlf, r );

				} else
				//
				{

					NSColor *nscolor;
					if ( selected )
					{
						nscolor = nscolor_text_highlight;
					} else {
						nscolor = nscolor_text_normal;
					}
	
					if ( delete_circle_fade_pressed.stop == FALSE )
					{
						NSColor *f = nscolor;
						NSColor *t = [NSColor whiteColor];

						nscolor = n_mac_nscolor_blend( f, t, delete_circle_fade_pressed.percent * 0.01 );
					}

					[attr setObject:nscolor forKey:NSForegroundColorAttributeName];

					NSString *text = n_mac_str2nsstring( character );
					char_rect = [self NonnonTxtboxDrawTextAdjust:text rect:char_rect];
					[text drawInRect:char_rect withAttributes:attr];
//NSLog( @"%@", text );

				}

//NSLog( @"%lld", char_index );
				index += char_index;
				sx    += char_size.width;

				if ( gradient_onoff )
				{
//NSLog( @"%f %f", sx, (CGFloat) csx - csy - csy - o );
					if ( sx >= ( csx - csy - csy - o - csy ) )
					{
						nscolor_text_normal = n_mac_nscolor_blend( nscolor_text_normal, nscolor_stripe, 0.5 );
					}
				}

			}

			// [!] : End-of-Line Marker

			if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
			{
				//
			} else
			if ( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )
			{
				//
			} else
			if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
			{
				//
			} else {
				NSRect char_rect = r;
				char_rect.origin.x += sx;

				NSString *crlf = @"\xe2\x86\xa9";
				[crlf drawInRect:char_rect withAttributes:attr_crlf];
			}

#ifdef N_TXTBOX_IME_ENABLE

			if ( ( ime_onoff )&&( i == n_focus ) )
			{

				n_posix_char *line = n_mac_nsstring2str( ime_nsstr );

				n_type_int range_f = ime_focus.location;
				n_type_int range_t = ime_focus.location + ime_focus.length;
				//if ( range_f == range_t ) { range_f = 0; }
//NSLog( @"%lld %lld", range_f, range_t );

				n_type_int index  = 0;
				CGFloat    sx     = ime_caret_fr.pxl.x;
				n_type_int tab    = 0;
				n_type_int glyph  = 0;
				n_type_int ime_sx = sx;
				n_posix_loop
				{//break;
					if ( line[ index ] == N_STRING_CHAR_NUL ) { break; }

					CGSize     char_size;
					n_type_int char_index;
					NSRect     char_rect = r;

					n_posix_char *character;
					character = n_mac_txtbox_character( font, font_size, (u8*) line, index, &char_size, &char_index, &tab );
//NSLog( @"#%lld : %ld", i, strlen( character ) );

					char_rect.origin.x   += sx;
					char_rect.origin.x   -= 1;
					char_rect.size.width  = char_size.width + 1;


					// [!] : underline based

					if ( ( glyph >= range_f )&&( glyph < range_t ) )
					{
						if ( underline_fx == -1 ) { underline_fx = char_rect.origin.x; }
						underline_tx = char_rect.origin.x + char_rect.size.width;
					}

					if ( i & 1 )
					{
						n_mac_draw_box( nscolor_stripe, char_rect );
					} else {
						n_mac_draw_box( nscolor_back  , char_rect );
					}
					[attr_ime setObject:nscolor_text_normal    forKey:NSForegroundColorAttributeName];

/*
					// [!] : highlight based

					if ( ( glyph >= range_f )&&( glyph < range_t ) )
					{
						[attr_ime setObject:nscolor_text_highlight forKey:NSForegroundColorAttributeName];
						n_mac_draw_box( nscolor_ime, char_rect );
					} else {
						if ( i & 1 )
						{
							n_mac_draw_box( nscolor_stripe, char_rect );
						} else {
							n_mac_draw_box( nscolor_back  , char_rect );
						}
						[attr_ime setObject:nscolor_text_normal    forKey:NSForegroundColorAttributeName];
					}
*/
					NSString *text = n_mac_str2nsstring( character );
					char_rect = [self NonnonTxtboxDrawTextAdjust:text rect:char_rect];
					[text drawInRect:char_rect withAttributes:attr_ime];

					index += char_index;
					sx    += char_size.width;
					glyph += 1;
					if ( glyph == ime_caret_offset ) { ime_sx = sx; }
				}

				n_string_free( line );


				// [!] : Underline #1

				underline_rect = NSMakeRect(
					padding + ime_caret_fr.pxl.x,
					r.origin.y + r.size.height - 2,
					sx - ime_caret_fr.pxl.x,
					2
				);


				// [!] : Fake Caret : IME version

				{
					n_type_gfx oy = (n_type_gfx) scroll * font_size.height;
					n_type_gfx  x = (n_type_gfx) padding + (n_type_gfx) ime_sx;
					n_type_gfx  y = (n_type_gfx) o + ime_caret_fr.pxl.y - oy - caret_centered_offset;
					n_type_gfx sx = (n_type_gfx) 2;
					n_type_gfx sy = (n_type_gfx) font_size.height;

					NSRect rect = NSMakeRect( x,y,sx,sy );

					[self NonnonTxtboxDrawCaretDraw:nil rect:rect color_bg:color_bg color_stripe:color_stripe focus:n_focus];
				}

			}
#endif

		}

		if ( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
		{
			if ( i == self.n_focus )
			{
				if ( self.n_listbox_edit_onoff )
				{
					NSRect rect = listbox_rect;
					rect.origin.x--;
					rect.origin.y--;
					//rect.size.width += 2;
					rect.size.height += 2;
					n_mac_draw_frame( nscolor_accent, rect );
				}
			}
		}


		r.origin.y += font_size.height;
		if ( r.origin.y > max_sy ) { break; }


		i++;
	}


	// [!] : Underline
	
	if ( underline_rect.origin.x != -1 )
	{

		n_bmp_flip_onoff = n_posix_true;

		n_type_gfx  x = underline_rect.origin.x;
		n_type_gfx  y = underline_rect.origin.y;
		n_type_gfx sx = underline_rect.size.width;
		n_type_gfx sy = 4;//underline_rect.size.height;

		n_type_gfx circle = sy;
		n_type_gfx step   = circle * 1.5;

		n_type_gfx xx = 0;
		n_posix_loop
		{//break;

			NSColor *clr = n_mac_argb2nscolor( color_crlf );
			NSRect   rct = NSMakeRect( x + xx,y,circle,circle );

			if ( underline_fx != -1 )
			{
				if ( ( ( x + xx ) >= underline_fx )&&( ( x + xx ) <= underline_tx ) )
				{
					clr = nscolor_ime;
				}
			}

			n_mac_draw_circle( clr, rct );

			xx += step;
			if ( xx >= sx ) { break; }
		}

		n_bmp_flip_onoff = n_posix_false;
	}


	// [!] : Line Number

	if (
		( self.n_mode == N_MAC_TXTBOX_MODE_EDITBOX )
		||
		( self.n_mode == N_MAC_TXTBOX_MODE_LISTBOX )
	)
	{
//{static int i = 0;NSLog( @"%d", i );i++;}

		n_bmp_flip_onoff = n_posix_true;

		n_type_int     i = 0;
		n_type_gfx pxl_y = 0;
		n_posix_loop
		{

			BOOL semi_indicator = FALSE;

			if ( ( n_txt_deco != NULL )&&( n_txt_data->sy == n_txt_deco->sy ) )
			{
				semi_indicator = TRUE;

				n_posix_char *deco = n_txt_get( n_txt_deco, scroll + i );

				if ( ( self.n_listbox_edit_onoff )&&( i == n_focus ) )
				{
					//
				} else
				if ( deco[ 0 ] == ' ' )
				{
					semi_indicator = FALSE;
				} else
				if ( deco[ 0 ] == 'B' )
				{
					//
				} else
				if ( deco[ 0 ] == 'u' )
				{
					semi_indicator = FALSE;
				} else
				if ( deco[ 0 ] == 'U' )
				{
					//
				}
			}

			n_mac_txtbox_draw_linenumber
			(
				linenumber_font,
				i, scroll, n_txt_data->sy,
				(n_type_int) MIN( caret_fr.cch.y, caret_to.cch.y ),
				(n_type_int) MAX( caret_fr.cch.y, caret_to.cch.y ),
				o, o + pxl_y, linenumber_size.width, font_size.height,
				nscolor_back,
				nscolor_text,
				n_txtbox_thin_highlight( n_txt_data, n_txt_deco, i + scroll, nscolor_back, nscolor_accent ),
				self.n_option_linenumber,
				semi_indicator
			);

			i++;

			pxl_y += font_size.height;
			if ( pxl_y > max_sy ) { break; }

		}

		n_bmp_flip_onoff = n_posix_false;
	}


	// [!] : Fake Caret
	if ( ime_onoff )
	{
		//
	} else {
		[self NonnonTxtboxDrawCaret_drawRect:nil
				     max_sx:( csx - csy + o )
			delete_circle_onoff:delete_circle_onoff
				   color_bg:color_bg
			       color_stripe:color_stripe
		];
	}


	// [!] : Delete Circle

	if ( delete_circle_onoff )
	{
		NSColor *color_bg;

		if ( delete_circle_fade_pressed.stop == FALSE )
		{
			NSColor *f = [NSColor  grayColor];
			NSColor *t = [NSColor whiteColor];

			color_bg = n_mac_nscolor_blend( f, t, delete_circle_fade_pressed.percent * 0.01 );
		} else
		if ( delete_circle_is_pressed )
		{
			color_bg = [NSColor blackColor];

			delete_circle_fade_hovered.stop =  TRUE;
			delete_circle_is_hovered        = FALSE;
		} else
		if ( delete_circle_fade_hovered.stop == FALSE )
		{
//NSLog( @"%x : %d", delete_circle_fade.color_fg, delete_circle_fade.percent );

			NSColor *f;
			if ( n_txtbox_first_responder == self )
			{
				f = nscolor_accent;
			} else {
				f = [NSColor grayColor];
			}

			NSColor *t = n_mac_nscolor_argb( 255, 255, 0, 128 );

			if ( delete_circle_fade_hovered.color_fg == n_bmp_white )
			{
				color_bg = n_mac_nscolor_blend( f, t, delete_circle_fade_hovered.percent * 0.01 );
			} else {
				color_bg = n_mac_nscolor_blend( t, f, delete_circle_fade_hovered.percent * 0.01 );
			}
		} else
		if ( delete_circle_is_hovered )
		{
			color_bg = n_mac_nscolor_argb( 255, 255, 0, 128 );
		} else
		if ( n_txtbox_first_responder == self )
		{
			color_bg = nscolor_accent;
		} else {
			color_bg = [NSColor grayColor];
		}

		CGFloat sz = csy - ( o * 2 );
		delete_circle_rect = NSMakeRect( csx - sz - o,o, sz,sz );
		n_mac_draw_circle( color_bg, delete_circle_rect );


		n_gdi gdi; n_gdi_zero( &gdi );

		gdi.sx                  = 15;
		gdi.sy                  = 15;

		gdi.base_color_bg       = n_bmp_white_invisible;
		gdi.base_color_fg       = n_bmp_white_invisible;
		gdi.text                = n_posix_literal( "×" );
		gdi.text_color_main     = n_bmp_white;
		gdi.text_size           = csy;

		n_bmp bmp1; n_bmp_zero( &bmp1 );
		n_gdi_bmp( &gdi, &bmp1 );

		n_bmp bmp2; n_bmp_zero( &bmp2 ); n_bmp_new_fast( &bmp2, gdi.sx, gdi.sy );
		n_bmp_flush( &bmp2, gdi.base_color_bg );
		n_bmp_transcopy( &bmp1, &bmp2, 0,0,gdi.sx,gdi.sy, 0,-1 );

//n_bmp_save( &bmp2, "/Users/nonnon/Desktop/ret.bmp" );

		NSRect rect = n_mac_rect_resize( delete_circle_rect, -2 );
//NSLog( @"%f %f", rect.origin.y, rect.size.height );

		n_mac_image_nbmp_direct_draw( &bmp2, &rect, NO );

		n_bmp_free_fast( &bmp1 );
		n_bmp_free_fast( &bmp2 );
	}


	// [!] : Scrollbar

	if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
	{
		//
	} else
	if ( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )
	{
		//
	} else
	if (1)//( is_whole_redraw )
	{

		// [!] : Fake Scroller

//NSLog( @"%f %f", page, txt_sy );


		// [!] : this code needs to be the same as NonnonTxtboxDrawScrollClamp

		n_type_gfx scroll_csy = (n_type_gfx) self.frame.size.height - ( offset * 2 );

		const n_type_gfx scroll_pixel_sx = 12;

		if ( n_corner_size == -1 ) { n_corner_size = scroll_pixel_sx; }
//NSLog( @"%f", n_corner_size );

		CGFloat shaft_sy         = scroll_csy - n_corner_size;
		CGFloat items_per_canvas = shaft_sy / font_size.height;
		CGFloat max_count        = (CGFloat) n_txt_data->sy;
		CGFloat rest             = font_size.height - fmod( shaft_sy, font_size.height );


		BOOL onoff = FALSE;

//NSLog( @"%f %f", items_per_canvas, max_count );
		if ( trunc( items_per_canvas ) < max_count )
		{
			onoff = TRUE;

			if ( rest ) { items_per_canvas -= 1.0; }
//NSLog( @"Rest %f", rest );

			n_type_gfx scrsx = scroll_pixel_sx;
			n_type_gfx scr_x = csx - o - scrsx;


			CGFloat step = font_size.height * ( shaft_sy / ( max_count * font_size.height ) );
			CGFloat page = max_count / items_per_canvas;

			n_type_gfx scr_y = o + ( scroll * step );
			n_type_gfx scrsy = MAX( 12, scroll_csy / page );

			scroll_step = shaft_sy / ( max_count * font_size.height );
			scroll_page = items_per_canvas;


			// [!] : for hit test
//scroller_rect = NSMakeRect( 0, 0, 0, 0 );
			scroller_rect_shaft = NSMakeRect( scr_x,     o, scrsx, shaft_sy );
			scroller_rect_thumb = NSMakeRect( scr_x, scr_y, scrsx,    scrsy );


			u32 color = color_fg;

			n_bmp_flip_onoff = n_posix_true;

			u32 color_shaft = n_bmp_alpha_replace_pixel( color, 16 );

			{
				NSColor *clr = n_mac_argb2nscolor( color_shaft );
				NSRect   rct = NSMakeRect( scr_x, o, scrsx, shaft_sy );
				n_mac_draw_roundrect( clr, rct, scrsx / 2 );
			}


			int hot    =  64;
			int normal =  96;
			int press  = 128;

			u32 color_thumb;
			if ( scrollbar_fade_captured_onoff )
			{
//NSLog( @"scrollbar_fade_captured_onoff" );

				u32 f = n_bmp_alpha_replace_pixel( color, press  );
				u32 t = n_bmp_alpha_replace_pixel( color, hot    );
				if ( thumb_is_captured )
				{
//NSLog( @"thumb_is_captured" );
					color_thumb = n_bmp_blend_pixel( t, f, (n_type_real) scrollbar_fade.percent * 0.01 );
				} else {
//NSLog( @"else" );
					if ( thumb_is_hovered )
					{
						t = n_bmp_alpha_replace_pixel( color, hot    );
					} else {
						t = n_bmp_alpha_replace_pixel( color, normal );
					}
					color_thumb = n_bmp_blend_pixel( f, t, (n_type_real) scrollbar_fade.percent * 0.01 );
				}
//NSLog( @"%d", scrollbar_fade.percent );
			} else
			if ( scrollbar_fade_hovered_onoff )
			{
//NSLog( @"scrollbar_fade_hovered_onoff" );

				u32 f = n_bmp_alpha_replace_pixel( color, hot    );
				u32 t = n_bmp_alpha_replace_pixel( color, normal );
				if ( thumb_is_captured )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, press  );
				} else
				if ( thumb_is_hovered )
				{
					color_thumb = n_bmp_blend_pixel( t, f, (n_type_real) scrollbar_fade.percent * 0.01 );
				} else {
					color_thumb = n_bmp_blend_pixel( f, t, (n_type_real) scrollbar_fade.percent * 0.01 );
				}
			} else {
//NSLog( @"else" );

				if ( thumb_is_captured )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, press  );
				} else
				if ( thumb_is_hovered )
				{
					color_thumb = n_bmp_alpha_replace_pixel( color, hot    );
				} else {
					color_thumb = n_bmp_alpha_replace_pixel( color, normal );
				}
			}

			{
				NSColor *clr = n_mac_argb2nscolor( color_thumb );
				NSRect   rct = NSMakeRect( scr_x,scr_y, scrsx,scrsy );
				n_mac_draw_roundrect( clr, rct, scrsx / 2 );
			}

			n_bmp_flip_onoff = n_posix_false;
		}


		// [!] : right-side margin

		NSRect rect_padding = NSMakeRect( csx - o, 0, o, csy );
		n_mac_draw_box( nscolor_back, rect_padding );


		// [!] : bottom-side margin

		rect_padding = NSMakeRect( 0, csy - o, csx, o );
		n_mac_draw_box( nscolor_back, rect_padding );

	}
	

	// [!] : Frame

	if ( redraw_caret_only )
	{
		//
	} else {

		[self setWantsLayer:YES];
		[self.layer setBorderWidth:2];
		//[self.layer setBackgroundColor:[[NSColor controlLightHighlightColor] CGColor]];
		[self.layer setBackgroundColor:[nscolor_back CGColor]];
		[self.layer setBorderColor:nscolor_frame.CGColor];

		CGFloat r = 10;
		if ( self.n_mode == N_MAC_TXTBOX_MODE_ONELINE )
		{
			r = csy / 4;
		} else
		if ( self.n_mode == N_MAC_TXTBOX_MODE_FINDBOX )
		{
			r = csy / 2;
		}
		
		[self.layer setCornerRadius:r];

	}

/*
	if ( debug )
	{
		n_mac_draw_box( [NSColor blackColor], self.frame );
	}
*/

	redraw_caret_only = FALSE;

	redraw_fy = -1;
	redraw_ty = -1;

/*
	{
		NSColor *clr = n_mac_nscolor_argb( 255, 0,200,255 );
		NSRect   rct = NSMakeRect( 100,100,200,200 );
		n_mac_draw_roundrect( clr, rct, 10 );
	}
*/
/*
	{
		NSColor *clr = n_mac_nscolor_argb( 255, 0,200,255 );
		NSRect   rct = NSMakeRect( 100,100,200,200 );
		n_mac_draw_circle( clr, rct );
	}
*/

//NSLog( @"%d", (int) n_posix_tickcount() - tick );
}


@end

